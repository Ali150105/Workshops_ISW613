<footer><i class="fa fa-copyright" aria-hidden="true"></i> Copyright &copy; 2024</footer>
</body>
</html>