<div class="container-fluid">
  <div class="jumbotron">
    <h1 class="display-4">Species</h1>
    <p class="lead">List of species</p>
    <hr class="my-4">
  </div>
  <table class="table table-striped table-inverse table-responsive">
    <thead class="thead-inverse">
      <tr>
        <th>ID</th>
        <th>Scientific Name</th>
        <th>Name</th>
      </tr>
      </thead>
      <?php var_dump($species) ?>
      <tbody>
        <tr>
          <td scope="row"></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td scope="row"></td>
          <td></td>
          <td></td>
        </tr>
      </tbody>
  </table>
</div>