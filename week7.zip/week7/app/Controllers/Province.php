<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Province extends BaseController
{
    public function create()
    {
        //

    }
}
